## CPU API

Code from OSTEP chapter [Interlude: Process API](http://pages.cs.wisc.edu/~remzi/OSTEP/cpu-api.pdf).

To compile, just type:
```
prompt> make
```

See the highly primitive `Makefile` for details.

Then run `p1`, `p2`, `p3`, or `p4`, as need be. Examples:

```
prompt> ./p1
```

```
prompt> ./p2
```

```
prompt> ./p3
```

```
prompt> ./p4
```




